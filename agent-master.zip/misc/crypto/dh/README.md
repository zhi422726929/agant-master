Diffie-Hellman key-exchange

http://en.wikipedia.org/wiki/Diffie%E2%80%93Hellman_key_exchange
