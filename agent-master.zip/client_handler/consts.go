package client_handler

const (
	SALT         = "DH"
	DEFAULT_GSID = "game1"
)









